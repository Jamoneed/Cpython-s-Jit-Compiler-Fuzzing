#!/bin/bash
# Phase 8 — labeille Real-World Packages Under Memory Pressure
# Run in a dedicated tmux window. Takes several hours.
# Usage: bash phase8_labeille_manual.sh [mmap_fail_rate]

FUZZING=~/fuzzing
PYTHON=$FUZZING/cpython/python
LOWMEM=$FUZZING/lowmem_tests
FAIL_MMAP=$LOWMEM/injectors/fail_mmap.so
MMAP_RATE=${1:-0.02}
REPORT=$LOWMEM/reports/phase8_$(date +%Y%m%d_%H%M%S).txt

log() { echo "$1" | tee -a "$REPORT"; }

log "=== Phase 8: labeille Real-World Packages ===" && log "Date: $(date)"
log "mmap fail rate: $MMAP_RATE" && log ""

# Prerequisites
if ! python3 -c "import labeille" 2>/dev/null; then
    log "Installing labeille..."
    pip install labeille
fi

# Create memory-pressured Python wrapper
WRAPPER=/tmp/jit_lowmem_python.sh
cat > $WRAPPER << EOF
#!/bin/bash
MMAP_FAIL_RATE=${MMAP_RATE} \\
PYTHON_JIT=1 \\
PYTHONFAULTHANDLER=1 \\
LD_PRELOAD=${FAIL_MMAP} \\
${PYTHON} "\$@"
EOF
chmod +x $WRAPPER
log "Wrapper: $WRAPPER (MMAP_FAIL_RATE=$MMAP_RATE)" && log ""

# Sync and resolve
log "Syncing labeille registry..."
labeille registry sync
log "Resolving top 50 packages..."
labeille resolve --top 50
log ""

# Run test suites
log "Starting labeille run (this takes hours)..."
labeille run \
    --target-python $WRAPPER \
    --workers 2 \
    --stop-after-crash 5 \
    2>&1 | tee -a "$REPORT"

# Analyze
log "" && log "=== Analysis ==="
labeille analyze run 2>&1 | tee -a "$REPORT"

# Benchmark: JIT+pressure vs no-JIT
log "" && log "=== Benchmark: JIT+pressure vs no-JIT ==="
NOJIT_WRAPPER=/tmp/nojit_python.sh
cat > $NOJIT_WRAPPER << EOF
#!/bin/bash
PYTHON_JIT=0 ${PYTHON} "\$@"
EOF
chmod +x $NOJIT_WRAPPER

labeille bench run \
    --condition "jit_lowmem:target_python=$WRAPPER" \
    --condition "nojit:target_python=$NOJIT_WRAPPER" \
    --top 20 \
    2>&1 | tee -a "$REPORT"

labeille bench compare results/bench_* 2>&1 | tee -a "$REPORT"

log "" && log "=== Phase 8 Complete: $(date) ==="
log "Crashes: $(ls $LOWMEM/crashes/phase8_* 2>/dev/null | wc -l) files"
