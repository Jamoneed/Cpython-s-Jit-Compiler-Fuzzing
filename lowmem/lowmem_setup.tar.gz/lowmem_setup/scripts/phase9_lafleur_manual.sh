#!/bin/bash
# Phase 9 — lafleur Mutations Under Memory Pressure
# Run in a dedicated tmux window. Let run for several hours.
# Usage: bash phase9_lafleur_manual.sh [mmap_fail_rate] [num_instances]

FUZZING=~/fuzzing
PYTHON=$FUZZING/cpython/python
LOWMEM=$FUZZING/lowmem_tests
FAIL_MMAP=$LOWMEM/injectors/fail_mmap.so
MMAP_RATE=${1:-0.05}
INSTANCES=${2:-2}
CAMPAIGN=$FUZZING/lowmem_campaign

log() { echo "[$(date +%H:%M:%S)] $1"; }

log "=== Phase 9: lafleur Under Memory Pressure ==="
log "mmap fail rate: $MMAP_RATE"
log "instances: $INSTANCES"

# Activate lafleur venv
source $FUZZING/lafleur_venv/bin/activate || {
    echo "ERROR: Could not activate lafleur venv at $FUZZING/lafleur_venv"
    exit 1
}

# Create campaign directory and seed corpus
mkdir -p $CAMPAIGN/corpus/jit_interesting_tests

# Copy seeds from main campaign if available
if [ -d "$FUZZING/campaign1/corpus/jit_interesting_tests" ]; then
    cp $FUZZING/campaign1/corpus/jit_interesting_tests/*.py \
       $CAMPAIGN/corpus/jit_interesting_tests/ 2>/dev/null
    log "Copied $(ls $CAMPAIGN/corpus/jit_interesting_tests/*.py 2>/dev/null | wc -l) seeds from campaign1"
else
    log "WARNING: No existing corpus found at $FUZZING/campaign1/corpus/"
    log "         Using an empty corpus — lafleur will start from scratch."
fi

# Create the mmap-injected Python wrapper
WRAPPER=/tmp/python_with_mmap_fail.sh
cat > $WRAPPER << EOF
#!/bin/bash
MMAP_FAIL_RATE=${MMAP_RATE} \\
PYTHON_JIT=1 \\
LD_PRELOAD=${FAIL_MMAP} \\
${PYTHON} "\$@"
EOF
chmod +x $WRAPPER
log "Wrapper created: $WRAPPER"

# Verify wrapper works
TEST_OUT=$(MMAP_FAIL_RATE=0 $WRAPPER -c "print('wrapper ok')" 2>&1)
if ! echo "$TEST_OUT" | grep -q "wrapper ok"; then
    log "ERROR: Wrapper failed sanity check. Output: $TEST_OUT"
    exit 1
fi
log "Wrapper sanity check: OK"

# Launch instances in tmux
SESSION=lowmem_fuzz
tmux new-session -d -s $SESSION 2>/dev/null || true

for i in $(seq 1 $INSTANCES); do
    WINDOW="lowmem_$i"
    tmux new-window -t $SESSION -n $WINDOW 2>/dev/null || true
    tmux send-keys -t $SESSION:$WINDOW "
source $FUZZING/lafleur_venv/bin/activate && \\
cd $CAMPAIGN && \\
MMAP_FAIL_RATE=$MMAP_RATE lafleur \\
    --target-python $WRAPPER \\
    --min-corpus-files 20 \\
    --dynamic-runs \\
    --deepening-probability 0.3 \\
    --runs 3 \\
    --instance-name lowmem-${i}
" C-m
    log "Launched instance $i in tmux window $WINDOW"
done

log ""
log "All $INSTANCES instances launched."
log "Attach:   tmux attach -t $SESSION"
log "Crashes:  ls $CAMPAIGN/crashes/"
log "Kill all: tmux kill-session -t $SESSION"
log ""
log "Let run for at least 4-8 hours for meaningful coverage."
log "Check for crashes periodically:"
log "  watch -n 30 'ls $CAMPAIGN/crashes/ 2>/dev/null | wc -l'"
